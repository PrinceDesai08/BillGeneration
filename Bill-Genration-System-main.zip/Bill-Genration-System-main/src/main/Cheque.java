package main;

public interface Cheque {
	public void generateCheque();
}
