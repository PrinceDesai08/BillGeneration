package main;

import main.employee.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import main.employee.*;

public class Company {
	private ArrayList<Object> globalDB = new ArrayList<Object>(); // Generic Array for saving Employee, Bill Objects
	public static int chequeNumber = 0;

	// "addData()" method will add the bill and employees objects
	public void addData(Object obj) {
		this.globalDB.add(obj);
	}

	// "displayChequeCount()" method will display total number of cheques issued
	public static void displayChequeCount() {
		int result = Company.chequeNumber; // Accessing object counts
		System.out.println("Total Cheques issued: " + result);
	}

	public void generate() throws ParseException {
		for (Object o : globalDB) {
			if (o.getClass().getSimpleName().equals("Part_Time_Employee")) {
				Part_Time_Employee pObj = (Part_Time_Employee) o;
				pObj.generateCheque(); // Part_Time_Employee class cheque will be generated
			
			} else if (o.getClass().getSimpleName().equals("Full_Time_Employee")) {
				Full_Time_Employee fObj = (Full_Time_Employee) o;
				fObj.generateCheque(); // Full_Time_Employee class cheque will be generated
				

			} else if (o.getClass().getSimpleName().equals("Bill")) {
				Bill bObj = (Bill) o;
				Date dDate = new SimpleDateFormat("dd MMMM yyyy").parse(bObj.dueDate);
				if(dDate.compareTo(new Date())<=0) {
				bObj.generateCheque(); // Bill class cheque will be generated
				
				}

			}
		
		}
		Company.displayChequeCount();
		

	}

}
