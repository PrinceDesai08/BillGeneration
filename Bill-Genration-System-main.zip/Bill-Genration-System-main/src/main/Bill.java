package main;

import java.text.DecimalFormat;

public class Bill implements Cheque {
	public String companyName;
	public double amount;
	public String dueDate;

	public Bill(String companyName, double amount, String date) {
		this.companyName = companyName;
		this.amount = amount;
		this.dueDate = date;
		
	}


	// generate cheques for bills
	public void generateCheque() {
		String payee = this.companyName;
		int chequeNum = ++Company.chequeNumber;
		Double billAmount = this.amount;
		DecimalFormat dec = new DecimalFormat("#0.00"); // setting up the precision for salary
		System.out.println("----------------------------------------------");
		System.out.println("Cheque Number: " + chequeNum + " \n" + "Payable to: " + payee + "\n" + "Amount: "
				+ ((billAmount % 1 == 0) ? (((Number) billAmount.intValue())) : dec.format(billAmount)) + " CAD\n"+"Due Date: "+dueDate);
		System.out.println("----------------------------------------------");

	}
}
