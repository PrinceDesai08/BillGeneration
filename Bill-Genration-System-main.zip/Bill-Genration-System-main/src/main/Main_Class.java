package main;

import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

import main.employee.Part_Time_Employee;
import main.employee.Full_Time_Employee;

public class Main_Class {

	// method to check date is valid or not
	static String checkDateValidity(String d) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("dd MMMM yyyy");
			format.setLenient(false); // will set the date entered by the user in the format (dd/MM/yyyy)
			Date userEnteredDate = format.parse(d);
			
			String pattern = "dd MMMM yyyy";
			String dateSplit[] = d.split(" ");
			int day = Integer.parseInt(dateSplit[0]);
			String month = dateSplit[1];
			int year = Integer.parseInt(dateSplit[2]);
			
			String datev = day + " " + month + " " + year;
			
			return datev;

		} catch (ParseException e) {
			return "Invalid";
		}
	}

	public static void main(String[] args) throws ParseException {

		Scanner inp = new Scanner(System.in);
		System.out.println("Welcome to Bill Generation System");

		Company c1 = new Company(); // Object of Company Class
		int userOption;
		boolean flag = true;
		
		while (flag) {
			System.out.println(
					"Enter 1 to add an employee | Enter 2 to add a Bill | 3 to issue cheques | 4 to exit application ");
			userOption = inp.nextInt();
			inp.nextLine();
			switch (userOption) {
			case 1:
				String firstName, lastName, jobType;
				int age, ID, echelon;
				double hoursWorked, salary;
				System.out.println("Enter P for Part Time | Enter F for Full Time");
				jobType = inp.nextLine();

				// getting part time employee details
				if (jobType.equalsIgnoreCase("P")) {

					System.out.println("Enter your First Name");
					firstName = inp.nextLine();
					System.out.println("Enter your Last Name");
					lastName = inp.nextLine();
					System.out.println("Enter your Employee ID");
					ID = inp.nextInt();
					System.out.println("Enter your Age");
					age = inp.nextInt();
					System.out.println("Enter your Echelon (1 to 5)");
					echelon = inp.nextInt();
					System.out.println("Enter No of hours worked");
					hoursWorked = inp.nextDouble();
					Part_Time_Employee partTimeEmployeeObj = new Part_Time_Employee(firstName, lastName, ID, age,
							echelon, hoursWorked);
					c1.addData(partTimeEmployeeObj);
					System.out.println("Successfully Saved \n");

				} else if (jobType.equalsIgnoreCase("F")) { // getting full time employee details
																											
					System.out.println("Enter your First Name");
					firstName = inp.nextLine();
					System.out.println("Enter your Last Name");
					lastName = inp.nextLine();
					System.out.println("Enter your Age");
					age = inp.nextInt();
					System.out.println("Enter your Employee ID");
					ID = inp.nextInt();
					System.out.println("Enter your Salary");
					salary = inp.nextDouble();
					Full_Time_Employee fullTimeEmployeeObj = new Full_Time_Employee(firstName, lastName, ID, age,
							salary);
					c1.addData(fullTimeEmployeeObj);
					System.out.println("Successfully Saved \n");

				}
				break;
			case 2: // getting bill input
				String companyName, dueDate = "";
				boolean dateFlag = true;
				double billAmount;
				System.out.println("Enter the Company name to pay the bill");
				companyName = inp.nextLine();
				System.out.println("Enter the Bill amount");
				billAmount = inp.nextDouble();
				inp.nextLine();
				while (dateFlag) { // will run till user enter valid date
					System.out.println("Enter due date of the bill in format - Date Month Year");
					dueDate = inp.nextLine();
					String dueDateModified = Main_Class.checkDateValidity(dueDate); // checking date validity
					
					if (dueDateModified == "Invalid") {
						System.out.println("Enter a valid date");

					} else {
						dateFlag = false;
					}
				}
				Bill billObj = new Bill(companyName, billAmount, dueDate);
				c1.addData(billObj);
				System.out.println("Successfully Saved \n");
				break;

			case 3: // displaying cheques
				c1.generate();
				System.out.println();
				break;

			case 4: // exiting application
				flag = false;
				System.out.println("Application closed successfully");
				break;

			default:
				System.out.println("Invalid input, Enter correct input option");

			}

		}

		inp.close();

	}

}
