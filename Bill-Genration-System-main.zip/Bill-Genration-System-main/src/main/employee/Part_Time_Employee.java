package main.employee;

import java.text.DecimalFormat;

import main.Cheque;
import main.Company;

public class Part_Time_Employee extends Employee implements Cheque {
	public int echelon;
	public double hoursWorked;
	public int hourlyRate;

	public Part_Time_Employee(String firstName, String lastName, int ID, int age, int echelon, double hoursWorked) {
		super(firstName, lastName, ID, age);
		this.echelon = echelon;
		this.hoursWorked = hoursWorked;
		// Setting hourlyRate based on echelon
		if (this.echelon == 1) {
			this.hourlyRate = 15;
		} else if (this.echelon == 2) {
			this.hourlyRate = 20;
		} else if (this.echelon == 3) {
			this.hourlyRate = 25;
		} else if (this.echelon == 4) {
			this.hourlyRate = 30;
		} else if (this.echelon == 5) {
			this.hourlyRate = 40;
		}
		
	}


	// "generateCheque()" method will generate the salary slip of part time employee
	public void generateCheque() {
		String payee = super.firstName + " " + super.lastName;
		int chequeNum = ++Company.chequeNumber;
		Double monthlySalary = this.hoursWorked * hourlyRate;
		DecimalFormat dec = new DecimalFormat("#0.00"); // setting up the precision for salary
		System.out.println("----------------------------------------------");
		System.out.println("Cheque Number: " + chequeNum + " \n" + "Payable to: " + payee + "\n" + "Amount: "
				+ ((monthlySalary % 1 == 0) ? (((Number) monthlySalary.intValue())) : dec.format(monthlySalary))
				+ " CAD");
		System.out.println("----------------------------------------------");

	}
}
