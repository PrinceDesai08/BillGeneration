package main.employee;

import java.text.DecimalFormat;

import main.Cheque;
import main.Company;

public class Full_Time_Employee extends Employee implements Cheque {
	public double salary;


	public Full_Time_Employee(String firstName, String lastName, int ID, int age, double salary) {
		super(firstName, lastName, ID, age);
		this.salary = salary;
		
	}


	// "generateCheque() method will generate the salary slip of full time employee
	public void generateCheque() {
		String payee = super.firstName + " " + super.lastName;
		int chequeNum = ++Company.chequeNumber;
		Double monthlySalary = this.salary;
		DecimalFormat dec = new DecimalFormat("#0.00"); // setting up the precision for salary
		System.out.println("----------------------------------------------");
		System.out.println("Cheque Number: " + chequeNum + " \n" + "Payable to: " + payee + "\n" + "Amount: "
				+ ((monthlySalary % 1 == 0) ? (((Number) monthlySalary.intValue())) : dec.format(monthlySalary))
				+ " CAD");
		System.out.println("----------------------------------------------");

	}

}
