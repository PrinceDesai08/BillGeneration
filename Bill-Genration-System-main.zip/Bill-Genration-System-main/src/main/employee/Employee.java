package main.employee;

public class Employee {

	public String firstName;
	public String lastName;
	public int ID;
	public int age;

	Employee(String firstName, String lastName, int ID, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.age = age;
	}

}
